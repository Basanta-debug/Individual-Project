from django.apps import AppConfig


class PowerConfig(AppConfig):
    name = 'power'
