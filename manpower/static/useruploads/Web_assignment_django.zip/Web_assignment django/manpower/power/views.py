from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from login.auth import user_only

def index(request):
    return render(request, 'power/home.html')

@login_required
@user_only
def about(request):
    return render(request,'power/about.html')

def gallery(request):
    return render(request,'power/gallery.html')

def contact(request):
    return render(request,'power/contact.html')

def req_doc(request):
    return render(request,'power/req_doc.html')